<?php
//define
define( 'KPLG_URL', plugins_url() );
define( 'KPLG_DIR', dirname( __FILE__ ) );
// Call shortcode file
include_once(KPLG_DIR. '/include/shortcode/slider.php');
include_once(KPLG_DIR. '/include/shortcode/slider-main.php');
include_once(KPLG_DIR. '/include/shortcode/section-title-one.php');
include_once(KPLG_DIR. '/include/shortcode/section-title-two.php');
include_once(KPLG_DIR. '/include/shortcode/section-title-three.php');
include_once(KPLG_DIR. '/include/shortcode/causes.php');
include_once(KPLG_DIR. '/include/shortcode/video-popup.php');
include_once(KPLG_DIR. '/include/shortcode/blog.php');
include_once(KPLG_DIR. '/include/shortcode/vorosa-gallery.php');
include_once(KPLG_DIR. '/include/shortcode/donner.php');
include_once(KPLG_DIR. '/include/shortcode/become-volunteer.php');
include_once(KPLG_DIR. '/include/shortcode/testimonial.php');
include_once(KPLG_DIR. '/include/shortcode/vorosa-volunter.php');
include_once(KPLG_DIR. '/include/shortcode/upcoming-events.php');
include_once(KPLG_DIR. '/include/shortcode/vorosa-countdown.php');
include_once(KPLG_DIR. '/include/shortcode/vorosa-tab.php');
include_once(KPLG_DIR. '/include/shortcode/requirements.php');
include_once(KPLG_DIR. '/include/shortcode/grow-up-humanity.php');
include_once(KPLG_DIR. '/include/shortcode/vorosa-map.php');include_once(KPLG_DIR. '/include/shortcode/vorosa-video-banner.php');